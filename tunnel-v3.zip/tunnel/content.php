<?php 
$title = "Universitas Serambi Mekkah"; 
$desc = " Berisi hasil-hasil kegiatan pengabdian dan pemberdayaan masyarakat berupa penerapan berbagai bidang ilmu diantaranya pendidikan, ekonomi, agama, teknik, pertanian, sosial humaniora, komputer dan kesehatan yang ditulis dalam bahasa Indonesia maupun bahasa Inggris.";